package com.codingNinjas.Bank.Account.Registration;

/*
 * 1. Add class attributes.
 * 2. Override all the interface methods.
 * 3. Implement setter injection
 */

public class savingsAccount implements Account{

}
